import { Test, TestingModule } from '@nestjs/testing';
import { TareaController } from './tarea.controller';
import { TareaService } from './tarea.service';
import { NotFoundException } from '@nestjs/common';
import { Tarea } from './tarea.entity';
import { CreateTareaDto } from './dto/create-tarea.dto';
import { UpdateTareaDto } from './dto/update-tarea.dto';

describe('TareaController', () => {
  let controller: TareaController;
  let service: TareaService;

  beforeEach(async () => {
    const mockService = {
      create: jest.fn(),
      findOne: jest.fn(),
      findAll: jest.fn(),
      update: jest.fn(),
      remove: jest.fn(),
      findByTitle: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      controllers: [TareaController],
      providers: [
        {
          provide: TareaService,
          useValue: mockService,
        },
      ],
    }).compile();

    controller = module.get<TareaController>(TareaController);
    service = module.get<TareaService>(TareaService);

    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('debería crear una tarea', async () => {
      const mockTarea: Tarea = {
        id: 1,
        title: 'Tarea de prueba',
        content: 'Contenido de la tarea',
      };
      const createTareaDto: CreateTareaDto = {
        title: 'Tarea 1',
        content: 'Contenido de la tarea',
      };
      jest.spyOn(service, 'create').mockResolvedValue(mockTarea);
      const result = await controller.create(createTareaDto);
      expect(result).toEqual(mockTarea);
      expect(service.create).toHaveBeenCalledWith(createTareaDto);
    });
  });

  describe('findAll', () => {
    it('debería retornar todas las tareas', async () => {
      const mockTareas: Tarea[] = [
        { id: 1, title: 'Tarea 1', content: 'Contenido 1' },
        { id: 2, title: 'Tarea 2', content: 'Contenido 2' },
      ];
      jest.spyOn(service, 'findAll').mockResolvedValue(mockTareas);
      const result = await controller.findAll();
      expect(result).toEqual(mockTareas);
      expect(service.findAll).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('debería retornar una tarea por id', async () => {
      const mockTarea: Tarea = {
        id: 1,
        title: 'Tarea 1',
        content: 'Contenido 1',
      };
      jest.spyOn(service, 'findOne').mockResolvedValue(mockTarea);
      const result = await controller.findOne('1');
      expect(result).toEqual(mockTarea);
      expect(service.findOne).toHaveBeenCalledWith(1);
    });

    it('debería lanzar NotFoundException si no se encuentra Tarea', async () => {
      jest.spyOn(service, 'findOne').mockRejectedValue(new NotFoundException());

      await expect(controller.findOne('999')).rejects.toThrow(NotFoundException);
      expect(service.findOne).toHaveBeenCalledWith(999);
    });
  });

  describe('update', () => {
    it('debería actualizar una tarea existente', async () => {
      const mockTarea: Tarea = {
        id: 1,
        title: 'Tarea actualizada',
        content: 'Contenido actualizado',
      };

      const updateTareaDto: UpdateTareaDto = {
        title: 'Tarea actualizada',
        content: 'Contenido actualizado',
      };

      jest.spyOn(service, 'update').mockResolvedValue(mockTarea);
      const result = await controller.update('1', updateTareaDto);
      expect(result).toEqual(mockTarea);
      expect(service.update).toHaveBeenCalledWith(1, updateTareaDto);
    });

    it('debería lanzar NotFoundException si la tarea a actualizar no existe', async () => {
      const updateTareaDto: UpdateTareaDto = {
        title: 'Tarea actualizada',
      };

      jest.spyOn(service, 'update').mockRejectedValue(new NotFoundException());

      await expect(controller.update('999', updateTareaDto)).rejects.toThrow(NotFoundException);
      expect(service.update).toHaveBeenCalledWith(999, updateTareaDto);
    });
  });

  describe('remove', () => {
    it('debería eliminar una tarea existente', async () => {
      jest.spyOn(service, 'remove').mockResolvedValue(undefined);
      await controller.remove('1');
      expect(service.remove).toHaveBeenCalledWith(1);
    });

    it('debería lanzar NotFoundException si la tarea a eliminar no existe', async () => {
      jest.spyOn(service, 'remove').mockRejectedValue(new NotFoundException());

      await expect(controller.remove('999')).rejects.toThrow(NotFoundException);
      expect(service.remove).toHaveBeenCalledWith(999);
    });
  });

  describe('findByTitle', () => {
    it('debería encontrar tareas que coincidan con el título', async () => {
      const mockTareas: Tarea[] = [
        { id: 1, title: 'Tarea Test', content: 'Contenido 1' },
        { id: 2, title: 'Test Tarea', content: 'Contenido 2' },
      ];
      jest.spyOn(service, 'findByTitle').mockResolvedValue(mockTareas);
      const result = await controller.findByTitle('Test');
      expect(result).toEqual(mockTareas);
      expect(service.findByTitle).toHaveBeenCalledWith('Test');
    });

    it('debería devolver un array vacío si no hay tareas con ese título', async () => {
      const emptyArray: Tarea[] = [];
      jest.spyOn(service, 'findByTitle').mockResolvedValue(emptyArray);
      const result = await controller.findByTitle('NoExiste');
      expect(result).toEqual(emptyArray);
      expect(service.findByTitle).toHaveBeenCalledWith('NoExiste');
    });
  });
});
