import { Test, TestingModule } from '@nestjs/testing';
import { TareaService } from './tarea.service';
import { Tarea } from './tarea.entity';
import { getRepositoryToken } from '@nestjs/typeorm';
import { NotFoundException } from '@nestjs/common';
import { Repository, ObjectLiteral, UpdateResult } from 'typeorm';

// MOCK del repositorio
const mockTareaRepository = () => ({
  create: jest.fn(),
  save: jest.fn(),
  find: jest.fn(),
  findOneBy: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
});

const mockTarea = {
  id: 1,
  title: 'Test Tarea',
  description: 'Test Description',
};

type MockRepository<T extends ObjectLiteral = any> = Partial<
  Record<keyof Repository<T>, jest.Mock>
>;

describe('TareaService', () => {
  let service: TareaService;
  let repository: MockRepository<Tarea>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TareaService,
        {
          provide: getRepositoryToken(Tarea),
          useValue: mockTareaRepository(),
        },
      ],
    }).compile();

    service = module.get<TareaService>(TareaService);
    repository = module.get<MockRepository<Tarea>>(getRepositoryToken(Tarea));
  });

  // Crear tarea
  it('debería crear una tarea', async () => {
    jest.spyOn(repository, 'save').mockResolvedValue(mockTarea as Tarea);

    const result = await service.create({
      title: 'Test Tarea',
      description: 'Test Description',
    });

    expect(result).toEqual(mockTarea);
    expect(repository.save).toHaveBeenCalled();
    expect(repository.create).toHaveBeenCalled();
  });

  // Mostrar todas las tareas
  it('debería encontrar todas las tareas', async () => {
    jest.spyOn(repository, 'find').mockResolvedValue([mockTarea] as Tarea[]);

    const result = await service.findAll();

    expect(result).toEqual([mockTarea]);
    expect(repository.find).toHaveBeenCalled();
  });

  // Buscar una tarea
  describe('buscar una tarea', () => {
    describe('cuando la tarea existe', () => {
      it('debería encontrar una tarea por id', async () => {
        jest.spyOn(repository, 'findOneBy').mockResolvedValue(mockTarea as Tarea);

        const id = 1;
        const result = await service.findOne(id);

        expect(result).toEqual(mockTarea);
        expect(repository.findOneBy).toHaveBeenCalledWith({ id });
      });
    });

    describe('cuando la tarea no existe', () => {
      it('debería lanzar NotFoundException', async () => {
        jest.spyOn(repository, 'findOneBy').mockResolvedValue(null);

        await expect(service.findOne(999)).rejects.toThrow(NotFoundException);
        expect(repository.findOneBy).toHaveBeenCalledWith({ id: 999 });
      });
    });
  });

  // Modificar tarea
  describe('modificar tarea', () => {
    describe('cuando la tarea existe', () => {
      it('debería modificar una tarea', async () => {
        const id = 1;
        const updateDto = { title: 'Updated Tarea' };
        const tareaActualizada = { ...mockTarea, ...updateDto };

        const updateResult = {
          affected: 1,
          raw: {},
          generatedMaps: [],
        } as UpdateResult;

        jest.spyOn(repository, 'update').mockResolvedValue(updateResult);
        jest.spyOn(service, 'findOne').mockResolvedValue(tareaActualizada);

        const result = await service.update(id, updateDto);

        expect(repository.update).toHaveBeenCalledWith(id, updateDto);
        expect(service.findOne).toHaveBeenCalledWith(id);
        expect(result).toEqual(tareaActualizada);
      });
    });

    describe('cuando la tarea no existe', () => {
      it('debería lanzar NotFoundException', async () => {
        const id = 999;
        const updateDto = { title: 'Updated Tarea' };

        const updateResult = {
          affected: 0,
          raw: {},
          generatedMaps: [],
        } as UpdateResult;

        jest.spyOn(repository, 'update').mockResolvedValue(updateResult);
        jest.spyOn(service, 'findOne').mockImplementation();

        await expect(service.update(id, updateDto)).rejects.toThrow(NotFoundException);
        expect(repository.update).toHaveBeenCalledWith(id, updateDto);
        expect(service.findOne).not.toHaveBeenCalled();
      });
    });
  });

  // Eliminar tarea
  describe('eliminar tarea', () => {
    describe('cuando la tarea existe', () => {
      it('debería eliminar la tarea', async () => {
        const id = 1;

        jest.spyOn(repository, 'delete').mockResolvedValue({ affected: 1 });

        await service.remove(id);
        expect(repository.delete).toHaveBeenCalledWith(id);
      });
    });

    describe('cuando la tarea no existe', () => {
      it('debería lanzar NotFoundException', async () => {
        const id = 999;

        jest.spyOn(repository, 'delete').mockResolvedValue({ affected: 0 });

        await expect(service.remove(id)).rejects.toThrow(NotFoundException);
        expect(repository.delete).toHaveBeenCalledWith(id);
      });
    });
  });
});
